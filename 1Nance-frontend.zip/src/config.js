  
    export const NBTokenAddress = "0xa5C7374159714A083a204395722ce3760A78119e"
    export const NBICOAddress = "0xf3a77590528d30afC881dA705C3083657f6e7Da9"    
    