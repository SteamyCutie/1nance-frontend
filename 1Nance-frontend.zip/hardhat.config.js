/**
 * @type import('hardhat/config').HardhatUserConfig
 */

require("@nomiclabs/hardhat-waffle");
require("@nomiclabs/hardhat-etherscan");

const ALCHEMY_API_KEY = "emBXg_BKwL_Y-QkGo0siq5jf7QX6pKGv";
const ROPSTEN_PRIVATE_KEY =
    "babf7da8cc284a5e8be0c35f5311b6500d2eb7a79c9651188f2576b2d8351b5e";
const HARDHAT_PRIVATE_KEY =
    "0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80";
module.exports = {
    solidity: "0.8.4",
    networks: {
        hardhat: {},
        localhost: {
            chainId: 31337,
            accounts: [`${HARDHAT_PRIVATE_KEY}`],
        },
        ropsten: {
            url: `https://eth-ropsten.alchemyapi.io/v2/${ALCHEMY_API_KEY}`,
            accounts: [`${ROPSTEN_PRIVATE_KEY}`],
        },
    },

    etherscan: {
        apiKey: {
            ropsten: "BUMP7B9BU6N26TTPBMGSSU69VUJSS5WSP5",
        },
    },

    paths: {
        sources: "./contracts",
        artifacts: "./src/artifacts",
    },
};
